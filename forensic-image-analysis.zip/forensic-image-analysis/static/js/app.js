// Application Data
const applicationData = {
    "monthly_stats": {
        "labels": ["Nov", "Dec", "Jan", "Feb", "Mar", "Apr"],
        "authentic": [45, 52, 48, 61, 55, 67],
        "copy_move": [12, 18, 15, 23, 19, 25],
        "splicing": [8, 11, 9, 14, 12, 16]
    },
    "system_status": {
        "cpu_usage": 15,
        "memory_usage": 42,
        "disk_usage": 68,
        "analyses_today": 23,
        "success_rate": 98.5
    }
};

// Global Variables
let currentFile = null;
let analysisInProgress = false;
let monthlyChart = null;
let socket = null;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize Socket.IO
    socket = io();
    
    socket.on('connect', function() {
        console.log('Connected to server');
    });
    
    socket.on('progress_update', function(data) {
        updateProgress(data.percent, data.message);
    });
    
    // Initialize dashboard
    updateSystemStats();
    createMonthlyChart();
    
    // Initialize navigation
    setupNavigation();
    
    updateBreadcrumb('Dashboard');
}

// Navigation Functions
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const pageId = this.getAttribute('data-page');
            showPage(pageId);
        });
    });
}

function showPage(pageId) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    // Show selected page
    const targetPage = document.getElementById(pageId + '-page');
    if (targetPage) {
        targetPage.classList.add('active');
    }
    
    // Update navigation
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    const activeLink = document.querySelector(`[data-page="${pageId}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    // Update breadcrumb
    const breadcrumbMap = {
        'dashboard': 'Dashboard',
        'upload': 'Upload & Analisis',
        'results': 'Hasil Analisis',
        'history': 'Riwayat',
        'export': 'Ekspor'
    };
    updateBreadcrumb(breadcrumbMap[pageId] || pageId);
}

function updateBreadcrumb(pageName) {
    const breadcrumbCurrent = document.getElementById('breadcrumb-current');
    if (breadcrumbCurrent) {
        breadcrumbCurrent.textContent = pageName;
    }
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('mobile-open');
}

// Dashboard Functions
function updateSystemStats() {
    const stats = applicationData.system_status;
    
    const analysesToday = document.getElementById('analyses-today');
    const successRate = document.getElementById('success-rate');
    const cpuUsage = document.getElementById('cpu-usage');
    const memoryUsage = document.getElementById('memory-usage');
    
    if (analysesToday) analysesToday.textContent = stats.analyses_today;
    if (successRate) successRate.textContent = stats.success_rate + '%';
    if (cpuUsage) cpuUsage.textContent = stats.cpu_usage + '%';
    if (memoryUsage) memoryUsage.textContent = stats.memory_usage + '%';
    
    // Update progress bars
    const progressBars = document.querySelectorAll('.progress-item .progress-bar');
    if (progressBars.length >= 3) {
        progressBars[0].style.width = stats.cpu_usage + '%';
        progressBars[1].style.width = stats.memory_usage + '%';
        progressBars[2].style.width = stats.disk_usage + '%';
    }
}

function createMonthlyChart() {
    const ctx = document.getElementById('monthlyChart');
    if (!ctx) return;
    
    const data = applicationData.monthly_stats;
    
    monthlyChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [
                {
                    label: 'Asli',
                    data: data.authentic,
                    backgroundColor: '#1FB8CD',
                    borderRadius: 4
                },
                {
                    label: 'Copy-Move',
                    data: data.copy_move,
                    backgroundColor: '#FFC185',
                    borderRadius: 4
                },
                {
                    label: 'Splicing',
                    data: data.splicing,
                    backgroundColor: '#B4413C',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        padding: 20
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#f3f4f6'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

// Upload & Analysis Functions
function handleDragOver(e) {
    e.preventDefault();
    const uploadArea = document.getElementById('upload-area');
    uploadArea.classList.add('dragover');
}

function handleDragLeave(e) {
    e.preventDefault();
    const uploadArea = document.getElementById('upload-area');
    uploadArea.classList.remove('dragover');
}

function handleDrop(e) {
    e.preventDefault();
    const uploadArea = document.getElementById('upload-area');
    uploadArea.classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleFileSelection(files[0]);
    }
}

function handleFileSelect(e) {
    const files = e.target.files;
    if (files.length > 0) {
        handleFileSelection(files[0]);
    }
}

function handleFileSelection(file) {
    if (!file.type.startsWith('image/')) {
        alert('Harap pilih file gambar yang valid');
        return;
    }
    
    currentFile = file;
    displayFilePreview(file);
    enableAnalysisButton();
}

function displayFilePreview(file) {
    const preview = document.getElementById('file-preview');
    const previewImg = document.getElementById('preview-img');
    const fileName = document.getElementById('file-name');
    const fileSize = document.getElementById('file-size');
    const fileType = document.getElementById('file-type');
    const fileDimensions = document.getElementById('file-dimensions');
    
    // Create file URL
    const fileURL = URL.createObjectURL(file);
    previewImg.src = fileURL;
    
    // Update file info
    fileName.textContent = file.name;
    fileSize.textContent = formatFileSize(file.size);
    fileType.textContent = file.type;
    
    // Get image dimensions
    previewImg.onload = function() {
        fileDimensions.textContent = `${this.naturalWidth} x ${this.naturalHeight}`;
    };
    
    preview.classList.remove('hidden');
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function enableAnalysisButton() {
    const button = document.getElementById('start-analysis-btn');
    button.disabled = false;
}

function startAnalysis() {
    if (!currentFile || analysisInProgress) return;
    
    analysisInProgress = true;
    const progressSection = document.getElementById('analysis-progress');
    progressSection.classList.remove('hidden');
    
    // Disable start button
    const startBtn = document.getElementById('start-analysis-btn');
    startBtn.disabled = true;
    startBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menganalisis...';
    
    // Create FormData and send to server
    const formData = new FormData();
    formData.append('image', currentFile);
    
    fetch('/analyze', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'completed') {
            // Analysis completed
            setTimeout(() => {
                showPage('results');
                resetAnalysisForm();
            }, 1000);
        } else if (data.error) {
            alert('Error: ' + data.error);
            resetAnalysisForm();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Terjadi kesalahan saat analisis');
        resetAnalysisForm();
    });
}

function updateProgress(percent, message) {
    const progressBar = document.getElementById('overall-progress-bar');
    const progressPercentage = document.getElementById('progress-percentage');
    
    if (progressBar) {
        progressBar.style.width = percent + '%';
    }
    if (progressPercentage) {
        progressPercentage.textContent = percent + '%';
    }
    
    // Add stage to analysis stages
    const stagesContainer = document.getElementById('analysis-stages');
    if (stagesContainer && message) {
        const stageElement = document.createElement('div');
        stageElement.className = 'stage-item';
        stageElement.innerHTML = `
            <div class="stage-status processing">
                <i class="fas fa-spinner fa-spin"></i>
            </div>
            <div class="stage-name">${message}</div>
            <div class="stage-time">${new Date().toLocaleTimeString()}</div>
        `;
        stagesContainer.appendChild(stageElement);
        
        // Mark previous stages as completed
        const allStages = stagesContainer.querySelectorAll('.stage-status');
        if (allStages.length > 1) {
            const prevStage = allStages[allStages.length - 2];
            prevStage.className = 'stage-status completed';
            prevStage.innerHTML = '<i class="fas fa-check"></i>';
        }
    }
}

function resetAnalysisForm() {
    analysisInProgress = false;
    const startBtn = document.getElementById('start-analysis-btn');
    startBtn.disabled = true;
    startBtn.innerHTML = 'Mulai Analisis';
    
    const progressSection = document.getElementById('analysis-progress');
    progressSection.classList.add('hidden');
    
    // Clear stages
    const stagesContainer = document.getElementById('analysis-stages');
    if (stagesContainer) {
        stagesContainer.innerHTML = '';
    }
    
    // Reset progress
    const progressBar = document.getElementById('overall-progress-bar');
    const progressPercentage = document.getElementById('progress-percentage');
    if (progressBar) progressBar.style.width = '0%';
    if (progressPercentage) progressPercentage.textContent = '0%';
}

// Utility Functions
function addRowUtility() {
    // Add responsive classes
    const containers = document.querySelectorAll('.row');
    containers.forEach(container => {
        if (!container.classList.contains('row')) {
            container.style.display = 'flex';
            container.style.flexWrap = 'wrap';
            container.style.margin = '0 -15px';
        }
    });
}

// Add missing CSS classes
const style = document.createElement('style');
style.textContent = `
    .row {
        display: flex;
        flex-wrap: wrap;
        margin: 0 -15px;
    }
    .col-md-3, .col-md-4, .col-md-6, .col-md-8 {
        padding: 0 15px;
        flex: 1;
        min-width: 250px;
    }
    .col-md-3 { flex: 0 0 25%; }
    .col-md-4 { flex: 0 0 33.333333%; }
    .col-md-6 { flex: 0 0 50%; }
    .col-md-8 { flex: 0 0 66.666667%; }
    .mb-3 { margin-bottom: 1rem; }
    .mb-4 { margin-bottom: 1.5rem; }
    .mt-3 { margin-top: 1rem; }
    .table-responsive {
        overflow-x: auto;
    }
    .hidden {
        display: none !important;
    }
`;
document.head.appendChild(style);
