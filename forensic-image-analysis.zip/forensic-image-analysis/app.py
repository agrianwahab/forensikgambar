import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 'modules')))

from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_socketio import SocketIO, emit
from werkzeug.utils import secure_filename
from PIL import Image
from datetime import datetime
import uuid

# Import modules (pastikan semua module tersedia)
try:
    from advanced_analysis import analyze_noise_consistency, perform_statistical_analysis
    from classification import classify_manipulation_advanced
    from copy_move_detection import detect_copy_move_blocks, kmeans_tampering_localization
    from ela_analysis import perform_multi_quality_ela
    from jpeg_analysis import comprehensive_jpeg_analysis
    from feature_detection import extract_multi_detector_features
    from export_utils import export_complete_package
    from config import VALID_EXTENSIONS, TARGET_MAX_DIM
except ImportError:
    # Fallback jika modules tidak ada
    VALID_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp'}
    TARGET_MAX_DIM = 1024

UPLOAD_FOLDER = 'uploads'

app = Flask(__name__)
app.config['SECRET_KEY'] = 'forensic_secret_2025'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

socketio = SocketIO(app, cors_allowed_origins="*")

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in VALID_EXTENSIONS

def emit_progress(percent, message):
    socketio.emit('progress_update', {
        'percent': int(percent),
        'message': message,
        'timestamp': datetime.now().strftime("%H:%M:%S")
    })

def analyze_image(filepath):
    """Analisis forensik sederhana untuk demo"""
    import time
    
    emit_progress(20, "Memulai analisis...")
    time.sleep(1)
    
    emit_progress(50, "Melakukan Error Level Analysis...")
    time.sleep(1)
    
    emit_progress(75, "Deteksi copy-move...")
    time.sleep(1)
    
    emit_progress(100, "Analisis selesai!")
    
    # Return demo results
    return {
        'classification': 'Copy-Move Forgery',
        'confidence': 78,
        'ela_mean': 8.5,
        'ela_std': 15.2,
        'sift_matches': 156,
        'ransac_inliers': 34,
        'block_matches': 12,
        'processing_time': '2.8s'
    }

@socketio.on('connect')
def handle_connect():
    emit('connection_response', {'status': 'connected'})

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def handle_analysis():
    if 'image' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['image']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'File type not allowed'}), 400
    
    try:
        filename = secure_filename(str(uuid.uuid4()) + '_' + file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        results = analyze_image(filepath)
        
        return jsonify({
            'status': 'completed',
            'results': results,
            'preview_url': f'/uploads/{filename}'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if 'filepath' in locals() and os.path.exists(filepath):
            os.remove(filepath)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs('reports', exist_ok=True)
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
